void drawDBox(int x1, int y1, int x2, int y2);
void gotoxy(int x, int y);
void clrscr();
void getInput(char* resp);
void getValue(char* str, int* num);
void menu();
